package main

import (
	"fmt"
	"gioui.org/app"
	"gioui.org/layout"
	"gioui.org/op"
	"gioui.org/unit"
	"github.com/x-module/gioui-plugins/theme"
	"github.com/x-module/gioui-plugins/widgets"
	"github.com/x-module/gioui-plugins/window"
	"io/ioutil"
)

func main() {
	th := theme.NewTheme()

	win := window.NewApplication(new(app.Window)).CenterWindow()
	win.Title("Hello, Gio!").Size(window.ElementSize{
		Height: 600,
		Width:  800,
	})

	// Load and parse Markdown file
	content, err := ioutil.ReadFile("source.md")
	if err != nil {
		panic(err)
	}

	renderer := widgets.NewMarkdown(th)
	widgets := renderer.Render(content)
	fmt.Println("renderer.widgets:", len(widgets))
	win.BackgroundColor(th.Color.DefaultWindowBgGrayColor)
	win.Frame(func(gtx layout.Context, ops op.Ops, win *app.Window) {
		layout.UniformInset(unit.Dp(20)).Layout(gtx, func(gtx layout.Context) layout.Dimensions {
			// gtx.Constraints.Min.X = gtx.Constraints.Max.X

			return layout.Flex{
				Axis: layout.Vertical,
			}.Layout(gtx, func() []layout.FlexChild {
				children := make([]layout.FlexChild, len(widgets))
				for i, widget := range widgets {
					children[i] = layout.Rigid(widget)
				}
				return children
			}()...)
		})
	})
	win.Run()
}
