package main

import (
	"fmt"
)

// numToLetter 将数字转换为大写字母（1 -> A, 2 -> B, ... 26 -> Z）
func numToLetter(num int) string {
	// 字母在 ASCII 表中的起始点是 'A' - 1，因为 1 应该对应 'A'
	offset := 'a' - 1
	// 计算给定数字对应的字母
	letter := rune(num) + offset
	// 将 rune 类型转换为 string 并返回
	return string(letter)
}

func main() {
	// 示例：将数字 1-26 转换为字母
	for i := 1; i <= 26; i++ {
		fmt.Printf("%d -> %s\n", i, numToLetter(i))
	}
}
