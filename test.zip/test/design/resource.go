/**
 * Created by Goland
 * @file   resource.go
 * @author 李锦 <lijin@cavemanstudio.net>
 * @date   2024/9/18 18:05
 * @desc   resource.go
 */

package design

import "image/color"

var (
	DefaultColor = color.NRGBA{R: 204, G: 204, B: 204, A: 255}
	TitleColor   = color.NRGBA{R: 102, G: 204, B: 204, A: 255}
)
