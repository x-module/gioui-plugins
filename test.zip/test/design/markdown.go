/**
 * Created by Goland
 * @file   markdown.go
 * @author 李锦 <lijin@cavemanstudio.net>
 * @date   2024/9/18 17:19
 * @desc   markdown.go
 */

package design

import (
	"gioui.org/font"
	"gioui.org/unit"
	"gioui.org/x/richtext"
	"github.com/yuin/goldmark"
	"github.com/yuin/goldmark/renderer"
	"github.com/yuin/goldmark/util"
	"image/color"
	"io/ioutil"
	"math"
)

type Renderer struct {
	md goldmark.Markdown
	nr *NodeRenderer

	Config Config
}

func (r *Renderer) Render(src []byte) ([]richtext.SpanStyle, error) {
	r.init()
	r.nr.SetConfig(r.Config)
	r.nr.UpdateCurrentColor(r.Config.DefaultColor)
	r.nr.UpdateCurrentFont(r.Config.DefaultFont)
	r.nr.UpdateCurrentSize(r.Config.DefaultSize)
	if err := r.md.Convert(src, ioutil.Discard); err != nil {
		return nil, err
	}
	return r.nr.Result(), nil
}

func NewRenderer() *Renderer {
	nr := NewNodeRenderer()
	md := goldmark.New(
		goldmark.WithRenderer(
			renderer.NewRenderer(
				renderer.WithNodeRenderers(
					util.PrioritizedValue{Value: nr, Priority: 0},
				),
			),
		),
	)
	return &Renderer{md: md, nr: nr}
}

// init
func (r *Renderer) init() {
	if r.Config.DefaultSize == 0 {
		r.Config.DefaultSize = 16
	}
	if r.Config.H6Size == 0 {
		r.Config.H6Size = unit.Sp(math.Round(1.2 * float64(r.Config.DefaultSize)))
	}
	if r.Config.H5Size == 0 {
		r.Config.H5Size = unit.Sp(math.Round(1.2 * float64(r.Config.H6Size)))
	}
	if r.Config.H4Size == 0 {
		r.Config.H4Size = unit.Sp(math.Round(1.2 * float64(r.Config.H5Size)))
	}
	if r.Config.H3Size == 0 {
		r.Config.H3Size = unit.Sp(math.Round(1.2 * float64(r.Config.H4Size)))
	}
	if r.Config.H2Size == 0 {
		r.Config.H2Size = unit.Sp(math.Round(1.2 * float64(r.Config.H3Size)))
	}
	if r.Config.H1Size == 0 {
		r.Config.H1Size = unit.Sp(math.Round(1.2 * float64(r.Config.H2Size)))
	}
	if r.Config.DefaultColor == (color.NRGBA{}) {
		r.Config.DefaultColor = color.NRGBA{R: 0xcc, G: 0xcc, B: 0xcc, A: 255}
	}
	if r.Config.MonospaceFont == (font.Font{}) {
		r.Config.MonospaceFont = font.Font{
			Typeface: "monospace",
			Weight:   r.Config.DefaultFont.Weight,
			Style:    r.Config.DefaultFont.Style,
		}
	}
	if r.Config.InteractiveColor == (color.NRGBA{}) {
		// Match the default material theme primary color.
		r.Config.InteractiveColor = color.NRGBA{R: 0x3f, G: 0x51, B: 0xb5, A: 255}
	}
}
