/**
 * Created by Goland
 * @file   renderer.go
 * @author 李锦 <lijin@cavemanstudio.net>
 * @date   2024/9/18 17:19
 * @desc   renderer.go
 */

package design

import (
	"fmt"
	"gioui.org/font"
	"gioui.org/unit"
	"gioui.org/x/richtext"
	"github.com/x-module/helper/debug"
	"github.com/yuin/goldmark/ast"
	"github.com/yuin/goldmark/renderer"
	"github.com/yuin/goldmark/util"
	"image/color"
	"strings"
)

// Config defines settings used by the renderer.
type Config struct {
	DefaultFont   font.Font
	MonospaceFont font.Font
	// Defaults to 12 if unset.
	DefaultSize unit.Sp
	// If unset, each level will be 1.2 times larger than the previous.
	H1Size, H2Size, H3Size, H4Size, H5Size, H6Size unit.Sp
	// Defaults to black.
	DefaultColor color.NRGBA
	// Defaults to blue.
	InteractiveColor color.NRGBA
}

// NodeRenderer transforms AST nodes into gio's richtext types
type NodeRenderer struct {
	TextObjects []richtext.SpanStyle
	Current     richtext.SpanStyle

	Config Config

	OrderedList  bool
	OrderedIndex int
}

func NewNodeRenderer() *NodeRenderer {
	return &NodeRenderer{}
}

// UpdateCurrentSize edits only the size of the current text.
func (g *NodeRenderer) UpdateCurrentSize(sp unit.Sp) {
	g.Current.Size = sp
}

func (g *NodeRenderer) UpdateCurrentFont(f font.Font) {
	reset := true
	if f.Style != 0 {
		reset = false
		g.Current.Font.Style = f.Style
	}
	if f.Typeface != "" {
		reset = false
		g.Current.Font.Typeface = f.Typeface
	}
	if f.Weight != 0 {
		reset = false
		g.Current.Font.Weight = f.Weight
	}
	if reset {
		g.Current.Font = f
	}
}

// UpdateCurrentColor edits only the color of the current text.
func (g *NodeRenderer) UpdateCurrentColor(c color.NRGBA) {
	g.Current.Color = c
}

// CommitCurrent compies the state of the Current field and appends it to
// TextObjects. This finalizes the content and style of that section of text.
func (g *NodeRenderer) CommitCurrent() {
	g.TextObjects = append(g.TextObjects, g.Current.DeepCopy())
}

// AppendNewline ensures that there is a newline character at the end
// of the most-recently-generated TextObject.
func (g *NodeRenderer) AppendNewline() {
	if len(g.TextObjects) < 1 {
		return
	}
	g.TextObjects[len(g.TextObjects)-1].Content += "\n"
}

// EnsureSeparationFromPrevious ensures that next text object will be
// visually separated from the previous by a blank line. It achieves
// this by inserting a synthetic label containing only newlines if
// necessary.
func (g *NodeRenderer) EnsureSeparationFromPrevious() {
	if len(g.TextObjects) < 1 {
		return
	}
	last := g.TextObjects[len(g.TextObjects)-1]
	if !strings.HasSuffix(last.Content, "\n\n") {
		if strings.HasSuffix(last.Content, "\n") {
			g.Current.Content = "\n"
		} else {
			g.Current.Content = "\n\n"
		}
		g.CommitCurrent()
	}
}

func (g *NodeRenderer) RegisterFuncs(reg renderer.NodeRendererFuncRegisterer) {
	// blocks
	//
	reg.Register(ast.KindDocument, g.renderDocument)
	reg.Register(ast.KindHeading, g.renderHeading)
	reg.Register(ast.KindBlockquote, g.renderBlockquote)
	reg.Register(ast.KindCodeBlock, g.renderCodeBlock)
	reg.Register(ast.KindFencedCodeBlock, g.renderFencedCodeBlock)
	reg.Register(ast.KindHTMLBlock, g.renderHTMLBlock)
	reg.Register(ast.KindList, g.renderList)
	reg.Register(ast.KindListItem, g.renderListItem)
	reg.Register(ast.KindParagraph, g.renderParagraph)
	reg.Register(ast.KindTextBlock, g.renderTextBlock)
	reg.Register(ast.KindThematicBreak, g.renderThematicBreak)
	//
	//	// inlines
	//
	reg.Register(ast.KindAutoLink, g.renderAutoLink)
	reg.Register(ast.KindCodeSpan, g.renderCodeSpan)
	reg.Register(ast.KindEmphasis, g.renderEmphasis)
	reg.Register(ast.KindImage, g.renderImage)
	reg.Register(ast.KindLink, g.renderLink)
	reg.Register(ast.KindRawHTML, g.renderRawHTML)
	reg.Register(ast.KindText, g.renderText)
	reg.Register(ast.KindString, g.renderString)
}

func (g *NodeRenderer) renderDocument(w util.BufWriter, source []byte, node ast.Node, entering bool) (ast.WalkStatus, error) {
	if !entering {
		return ast.WalkContinue, nil
	}
	fmt.Println("render document")
	return ast.WalkContinue, nil
}

func (g *NodeRenderer) renderHeading(w util.BufWriter, source []byte, node ast.Node, entering bool) (ast.WalkStatus, error) {
	n := node.(*ast.Heading)
	fmt.Println("render heading,level：", n.Level)
	if entering {
		g.EnsureSeparationFromPrevious()
		switch n.Level {
		case 1:
			g.Current.Size = g.Config.H1Size
		case 2:
			g.Current.Size = g.Config.H2Size
		case 3:
			g.Current.Size = g.Config.H3Size
		case 4:
			g.Current.Size = g.Config.H4Size
		case 5:
			g.Current.Size = g.Config.H5Size
		case 6:
			g.Current.Size = g.Config.H6Size
		}
	}
	g.Current.Color = TitleColor
	return ast.WalkContinue, nil
}

func (g *NodeRenderer) renderBlockquote(w util.BufWriter, source []byte, node ast.Node, entering bool) (ast.WalkStatus, error) {
	fmt.Println("render blockquote")
	return ast.WalkContinue, nil
}

func (g *NodeRenderer) renderCodeBlock(w util.BufWriter, source []byte, node ast.Node, entering bool) (ast.WalkStatus, error) {
	fmt.Println("render code block")
	return ast.WalkContinue, nil
}

func (g *NodeRenderer) renderFencedCodeBlock(w util.BufWriter, source []byte, node ast.Node, entering bool) (ast.WalkStatus, error) {
	fmt.Println("render fenced code block")
	return ast.WalkContinue, nil
}

func (g *NodeRenderer) renderHTMLBlock(w util.BufWriter, source []byte, node ast.Node, entering bool) (ast.WalkStatus, error) {
	fmt.Println("render html block")
	return ast.WalkContinue, nil
}

func (g *NodeRenderer) renderList(w util.BufWriter, source []byte, node ast.Node, entering bool) (ast.WalkStatus, error) {
	fmt.Println("render list")
	n := node.(*ast.List)
	if entering {
		g.EnsureSeparationFromPrevious()
		g.OrderedList = n.IsOrdered()
		g.OrderedIndex = 1
	} else {
	}
	g.Current.Color = g.Config.DefaultColor

	return ast.WalkContinue, nil
}

func (g *NodeRenderer) renderListItem(w util.BufWriter, source []byte, node ast.Node, entering bool) (ast.WalkStatus, error) {
	if entering {
		fmt.Println("render list item")
		if g.OrderedList {
			g.Current.Content = fmt.Sprintf(" %d. ", g.OrderedIndex)
			g.OrderedIndex++
		} else {
			g.Current.Content = " • "
		}
		g.CommitCurrent()
	} else if len(g.TextObjects) > 0 {
		g.AppendNewline()
	}
	return ast.WalkContinue, nil
}

func (g *NodeRenderer) renderParagraph(w util.BufWriter, source []byte, node ast.Node, entering bool) (ast.WalkStatus, error) {
	fmt.Println("render paragraph")
	return ast.WalkContinue, nil
}

func (g *NodeRenderer) renderTextBlock(w util.BufWriter, source []byte, node ast.Node, entering bool) (ast.WalkStatus, error) {
	fmt.Println("render text block")
	return ast.WalkContinue, nil
}

func (g *NodeRenderer) renderThematicBreak(w util.BufWriter, source []byte, node ast.Node, entering bool) (ast.WalkStatus, error) {
	fmt.Println("render thematic break")
	return ast.WalkContinue, nil
}

func (g *NodeRenderer) renderAutoLink(w util.BufWriter, source []byte, node ast.Node, entering bool) (ast.WalkStatus, error) {
	fmt.Println("render auto link")
	return ast.WalkContinue, nil
}

func (g *NodeRenderer) renderCodeSpan(w util.BufWriter, source []byte, node ast.Node, entering bool) (ast.WalkStatus, error) {
	fmt.Println("render code span")
	return ast.WalkContinue, nil
}

func (g *NodeRenderer) renderEmphasis(w util.BufWriter, source []byte, node ast.Node, entering bool) (ast.WalkStatus, error) {
	fmt.Println("render emphasis")
	return ast.WalkContinue, nil
}

func (g *NodeRenderer) renderImage(w util.BufWriter, source []byte, node ast.Node, entering bool) (ast.WalkStatus, error) {
	fmt.Println("render image")
	return ast.WalkContinue, nil
}

func (g *NodeRenderer) renderLink(w util.BufWriter, source []byte, node ast.Node, entering bool) (ast.WalkStatus, error) {
	fmt.Println("render link")
	return ast.WalkContinue, nil
}

func (g *NodeRenderer) renderRawHTML(w util.BufWriter, source []byte, node ast.Node, entering bool) (ast.WalkStatus, error) {
	fmt.Println("render raw html")
	return ast.WalkContinue, nil
}

func (g *NodeRenderer) renderText(w util.BufWriter, source []byte, node ast.Node, entering bool) (ast.WalkStatus, error) {
	if !entering {
		return ast.WalkContinue, nil
	}

	n := node.(*ast.Text)
	n.IsRaw()
	debug.DumpPrint(n)
	segment := n.Segment
	content := segment.Value(source)
	g.Current.Content = g.getBlank(source, segment.Start, segment.Start) + string(content)
	fmt.Println("render text,content：", string(content))
	g.CommitCurrent()
	g.Current.Color = DefaultColor
	return ast.WalkContinue, nil
}

func (g *NodeRenderer) getBlank(source []byte, start int, end int) string {
	start--
	if start < 0 {
		start = 0
	}
	chars := source[start:end]
	fmt.Println("start:", start, " end:", end, " content:", string(chars))
	if string(chars) == " " {
		return g.getBlank(source, start-1, end)
	} else {
		return string(chars)
	}
}

func (g *NodeRenderer) renderString(w util.BufWriter, source []byte, node ast.Node, entering bool) (ast.WalkStatus, error) {
	return ast.WalkContinue, nil
}

// Result returns the accumulated text objects.
func (g *NodeRenderer) Result() []richtext.SpanStyle {
	o := g.TextObjects
	g.TextObjects = nil
	return o
}

func (g *NodeRenderer) SetConfig(config Config) {
	g.Config = config
}
