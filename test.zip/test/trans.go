package main

import (
	"fmt"
	"golang.org/x/net/html"
	"os"
	"strings"
)

func main() {
	// 获取一个HTML页面的节点树
	bit, _ := os.ReadFile("test.html")
	htmlStr := string(bit)
	doc, err := html.Parse(strings.NewReader(htmlStr))
	if err != nil {
		panic(err)
	}
	// 遍历节点树，找到<body>标签，并提取其中的内容
	var getContent func(*html.Node) string
	getContent = func(n *html.Node) string {
		fmt.Println("n.Type:", n.Type)
		fmt.Println("n.Data:", n.Data)

		if n.Type == html.ElementNode {
			fmt.Println("n.Data:", n.Data)
		}
		if n.Type == html.DoctypeNode && n.Data == "html" {
			var content string
			fmt.Println("-----------------")
			fmt.Println(n.FirstChild)
			for c := n.FirstChild; c != nil; c = c.NextSibling {
				if c.Type == html.TextNode {
					content += c.Data
				} else {
					content += getContent(c)
				}
			}
			return content
		}
		for c := n.FirstChild; c != nil; c = c.NextSibling {
			if content := getContent(c); content != "" {
				return content
			} else {
				return c.Data
			}
		}
		return ""
	}
	content := getContent(doc)
	fmt.Println(content)
}
