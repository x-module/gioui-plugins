package main

import (
	"fmt"
	"github.com/x-module/helper/debug"
	"golang.org/x/net/html"
	"strings"
)

// \<span\sclass\=\".?\"\>

func main() {
	htmlStr := `<html><body><code><span class="line"><span class="cl"><span class="kn">package</span> <span class="nx">main</span>
    </span></span><span class="line"><span class="cl"><span class="kn">import</span> <span class="s">&#34;fmt&#34;</span>
	</span></span><span class="line"><span class="cl"><span class="kd">func</span> <span class="nf">main</span><span class="p">()</span> <span class="p">{</span>
	</span></span><span class="line"><span class="cl"><span class="nx">fmt</span><span class="p">.</span><span class="nf">Println</span><span class="p">(</span><span class="s">&#34;Hello, World!&#34;</span><span class="p">)</span>
	</span></span><span class="line"><span class="cl"><span class="p">}</span></span></span></code></body>
	</html>
	`
	doc, err := html.Parse(strings.NewReader(htmlStr))
	if err != nil {
		panic(err)
	}

	result := make(map[string]interface{})
	traverse(doc, result)

	fmt.Println(result)
}

func traverse(n *html.Node, result map[string]interface{}) {
	debug.DumpPrint(n.Type)
	debug.DumpPrint(n.Data)
	debug.DumpPrint(n.Attr)
	debug.DumpPrint(n.FirstChild)
	debug.DumpPrint(n.NextSibling)

	if n.Type == html.ElementNode {
		if n.Data == "span" || n.Data == "code" {
			class := ""
			for _, attr := range n.Attr {
				if attr.Key == "class" {
					class = attr.Val
					break
				}
			}
			if class != "" {
				if _, ok := result[class]; !ok {
					result[class] = make(map[string]interface{})
				}
				childMap := result[class].(map[string]interface{})
				for c := n.FirstChild; c != nil; c = c.NextSibling {
					traverse(c, childMap)
				}
			}
		}
	} else if n.Type == html.TextNode {
		text := strings.TrimSpace(n.Data)
		if text != "" {
			result["text"] = text
		}
	}
}
