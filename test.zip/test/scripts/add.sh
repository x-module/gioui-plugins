#!/bin/bash
# 拉取git库代码
cd data && git add . && git commit -m "update" && git push origin master