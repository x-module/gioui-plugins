#!/bin/bash
# 拉取git库代码
git clone git@codeup.aliyun.com:66e1507ed5ea2c3de15129f6/notebook.git data