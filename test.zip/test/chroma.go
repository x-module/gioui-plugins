package main

import (
	"bytes"
	"github.com/alecthomas/chroma/v2/formatters"
	"github.com/alecthomas/chroma/v2/quick"
	"github.com/x-module/helper/debug"
	"os"
)

var source12 = `
style := styles.Get("swapoff")
if style == nil {
  style = styles.Fallback
}
formatter := formatters.Get("html")
if formatter == nil {
  formatter = formatters.Fallback
}
`
var source2 = `
1. 经验加成：
    2. VIP
    13. VIP3
`
var source3 = `
| 标题1 | 标题2 | 标题3 |
|-------|-------|-------|
| 单元格1 | 单元格2 | 单元格3 |
| 单元格4 | 单元格5 | 单元格6 |
`

func main() {
	f := formatters.Names()
	debug.DumpPrint(f)
	var html bytes.Buffer
	// 使用 Chroma 快速高亮显示代码，并将输出存储到变量 html 中
	err := quick.Highlight(&html, source12, "go", "html", "monokai")
	if err != nil {
		panic(err)
	}
	os.WriteFile("test.html", html.Bytes(), 0644)
}
