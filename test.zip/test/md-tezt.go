/**
 * Created by Goland
 * @file   md-tezt.go
 * @author 李锦 <lijin@cavemanstudio.net>
 * @date   2024/9/18 17:37
 * @desc   md-tezt.go
 */

package main

import (
	"gioui.org/app"
	"gioui.org/layout"
	"gioui.org/op"
	"gioui.org/unit"
	"gioui.org/x/richtext"
	"github.com/x-module/gioui-plugins/theme"
	"github.com/x-module/gioui-plugins/widgets"
	"github.com/x-module/gioui-plugins/window"
	"test/design"
)

var source1 = `
### 通行证经验
#### 来源一
1. 走现有比赛玩家经验逻辑。保存从活动开始开始累计的玩家经验值增加，之后按照配置的阈值触发转换逻辑。
2. 加成的是玩家经验
3. 经验加成：
    1. VIP
    2. 好友组队
4. 转换后减掉转换的值
`
var source = `
1. 经验加成：
    1. VIP
`

func main() {
	var th = theme.NewTheme()
	card := widgets.NewCard(th)
	win := window.NewApplication(new(app.Window)).CenterWindow()
	win.Title("Hello, Gio!").Size(window.ElementSize{
		Height: 600,
		Width:  800,
	})
	var textState richtext.InteractiveText
	md := design.NewRenderer()
	cache, _ := md.Render([]byte(source))
	// debug.DumpPrint(cache)
	win.BackgroundColor(th.Color.DefaultWindowBgGrayColor)
	win.Frame(func(gtx layout.Context, ops op.Ops, win *app.Window) {
		layout.UniformInset(unit.Dp(20)).Layout(gtx, func(gtx layout.Context) layout.Dimensions {
			return layout.Flex{Axis: layout.Vertical}.Layout(gtx,
				layout.Rigid(func(gtx layout.Context) layout.Dimensions {
					return card.Layout(gtx, func(gtx layout.Context) layout.Dimensions {
						return layout.UniformInset(unit.Dp(4)).Layout(gtx, func(gtx layout.Context) layout.Dimensions {
							return richtext.Text(&textState, th.Material().Shaper, cache...).Layout(gtx)
						})
					})
				}),
			)
		})
	})
	win.Run()
}
