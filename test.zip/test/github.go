/**
 * Created by Goland
 * @file   github.go
 * @author 李锦 <lijin@cavemanstudio.net>
 * @date   2024/9/11 16:06
 * @desc   github.go
 */

package main

import (
	"fmt"
	"github.com/x-module/helper/cmd"
	_ "golang.org/x/exp/shiny/widget/node"
)

func clone() {
	out, res, err := cmd.Run("sh", "scripts/clone.sh")
	if err != nil {
		fmt.Println(err)
		println(string(out), string(res))
		panic(err)
	}
	println(string(out), string(res))
}

func sync() {
	out, res, err := cmd.Run("sh", "scripts/add.sh")
	if err != nil {
		fmt.Println(err)
		println(string(out), string(res))
		panic(err)
	}
	println(string(out), string(res))
}

func main() {
	sync()
}
