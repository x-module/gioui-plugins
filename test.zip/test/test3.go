package main

import (
	"fmt"
	"github.com/yuin/goldmark"
	"github.com/yuin/goldmark/ast"
	"github.com/yuin/goldmark/extension"
	"github.com/yuin/goldmark/parser"
	"github.com/yuin/goldmark/renderer/html"
	"github.com/yuin/goldmark/text"
	"os"
)

func main() {
	st, _ := os.ReadFile("source.md")
	reader := text.NewReader(st)

	md := goldmark.New(
		goldmark.WithExtensions(extension.GFM),
		goldmark.WithParserOptions(
			parser.WithAutoHeadingID(),
		),
		goldmark.WithRendererOptions(
			html.WithHardWraps(),
			html.WithXHTML(),
		),
	)
	// doc := goldmark.DefaultParser().Parse(reader)
	doc := md.Parser().Parse(reader)

	ast.Walk(doc, func(node ast.Node, entering bool) (ast.WalkStatus, error) {
		if entering {
			fmt.Println(entering, "type:", node.Kind().String())
		}
		return ast.WalkContinue, nil
	})
}
