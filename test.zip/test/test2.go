package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"github.com/yuin/goldmark"
	"github.com/yuin/goldmark/ast"
	"github.com/yuin/goldmark/extension"
	"github.com/yuin/goldmark/parser"
	"github.com/yuin/goldmark/renderer/html"
	"github.com/yuin/goldmark/text"
	"os"
	"strings"
)

var htmlTag []string

type Element struct {
	Type       string            `json:"type"`
	Attributes map[string]string `json:"attributes"`
	Content    string            `json:"content"`
	Children   []Element         `json:"children"`
}

func parseNode(node ast.Node, source []byte) Element {
	elem := Element{
		Type: node.Kind().String(),
	}
	// fmt.Println("type:", node.Kind().String())
	switch n := node.(type) {
	case *ast.Text:
		elem.Content = string(n.Text(source))
		tags := strings.Join(htmlTag, "@")
		if tags != "" {
			tags = strings.ReplaceAll(tags, ">", "")
			tags = strings.ReplaceAll(tags, "<", "")
			elem.Attributes = map[string]string{"style": tags}
			fmt.Println("htmlTag:", tags)
		}
	case *ast.Link:
		elem.Attributes = map[string]string{"destination": string(n.Destination), "title": string(n.Title)}
	case *ast.Image:
		elem.Attributes = map[string]string{"src": string(n.Destination), "title": string(n.Title)}
	case *ast.List:
		if n.IsOrdered() {
			elem.Type = "OrderedList"
		} else {
			elem.Type = "UnorderedList"
		}
	case *ast.FencedCodeBlock:
		lang := string(n.Language(source))
		elem.Attributes = map[string]string{"language": lang}
		var buf bytes.Buffer
		for i := 0; i < n.Lines().Len(); i++ {
			line := n.Lines().At(i)
			buf.Write(line.Value(source))
		}
		elem.Type = "CodeBlock"
		elem.Content = buf.String()
	case *ast.Paragraph:
		elem.Type = "Paragraph"
	case *ast.Heading:
		elem.Type = "Heading"
		elem.Attributes = map[string]string{"level": fmt.Sprintf("%d", n.Level)}
	case *ast.Emphasis:
		elem.Type = "Emphasis"
		// 斜体通常是一个星号或下划线
		// 加粗是两个星号或下划线
		if n.Level == 1 {
			elem.Attributes = map[string]string{"style": "italic"}
		} else if n.Level == 2 {
			elem.Attributes = map[string]string{"style": "bold"}
		}
	case *ast.String:
		elem.Type = "String"
	case *ast.Blockquote:
		elem.Type = "Blockquote"
	case *ast.CodeBlock:
		elem.Type = "Code"
		elem.Content = string(n.Text(source))
	case *ast.ListItem:
		elem.Type = "ListItem"
	case *ast.HTMLBlock, *ast.RawHTML:
		at := n.(*ast.RawHTML).Segments.At(0)
		tag := string(at.Value(source))
		fmt.Println("tag:", tag)
		if strings.Contains(tag, "/") {
			htmlTag = nil
		} else {
			htmlTag = append(htmlTag, tag)
		}
	}
	for child := node.FirstChild(); child != nil; child = child.NextSibling() {
		childElem := parseNode(child, source)
		if len(childElem.Children) != 0 || strings.TrimSpace(childElem.Content) != "" {
			elem.Children = append(elem.Children, childElem)
		}
	}
	return elem
}

func main() {
	st, _ := os.ReadFile("source.md")
	reader := text.NewReader(st)

	md := goldmark.New(
		goldmark.WithExtensions(extension.GFM),
		goldmark.WithParserOptions(
			parser.WithAutoHeadingID(),
		),
		goldmark.WithRendererOptions(
			html.WithHardWraps(),
			html.WithXHTML(),
		),
	)

	// doc := goldmark.DefaultParser().Parse(reader)
	doc := md.Parser().Parse(reader)

	rootElem := parseNode(doc, st)
	jsonData, err := json.MarshalIndent(rootElem, "", "    ")
	if err != nil {
		fmt.Printf("Error serializing to JSON: %v\n", err)
		return
	}
	os.WriteFile("output.json", jsonData, 0644)
}
