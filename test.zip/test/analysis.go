/**
 * Created by Goland
 * @file   analysis.go
 * @author 李锦 <lijin@cavemanstudio.net>
 * @date   2024/9/13 16:36
 * @desc   analysis.go
 */

package main

import (
	"bytes"
	"fmt"
	"gioui.org/app"
	"gioui.org/layout"
	"gioui.org/op"
	"gioui.org/unit"
	"gioui.org/x/richtext"
	"github.com/alecthomas/chroma/v2/quick"
	"github.com/lucasb-eyer/go-colorful"
	"github.com/x-module/gioui-plugins/theme"
	"github.com/x-module/gioui-plugins/widgets"
	"github.com/x-module/gioui-plugins/window"
	"golang.org/x/net/html"
	"image/color"
	"regexp"
	"strconv"
	"strings"
)

var cssList = map[string]CssObj{}
var cssMap = map[string]CssObj{}

// var response = map[string]CssObj{}
var code = `
func main() {
	imgData := []byte{ /* 你的图片数据 */ }
	img, err := png.Decode(bytes.NewReader(imgData))
	if err != nil {
		imgData = []byte{ /* 你的图片数据 */ }
		fmt.Println("Error decoding image:", err)
		return
	}
	file, err := os.Create("new_image.png")
	if err != nil {
		fmt.Println("Error creating file:", err)
		return
	}
	defer file.Close()
	// 将 image.Image 编码为 PNG 并写入文件
	err = png.Encode(file, img)
	if err != nil {
		fmt.Println("Image saved to new_image.png")
	}
}

`

func main() {
	var htmlContent bytes.Buffer
	// 使用 Chroma 快速高亮显示代码，并将输出存储到变量 html 中
	err := quick.Highlight(&htmlContent, code, "go", "html", "monokai")
	if err != nil {
		panic(err)
	}
	re := regexp.MustCompile(`(?s)<style.*</style>`)
	matches := re.FindAllString(htmlContent.String(), -1)
	cssContent := strings.ReplaceAll(matches[0], "<style type=\"text/css\">", "")
	name := strings.ReplaceAll(cssContent, "</style>", "")
	css(name)
	// //================================================================================================
	htmlStr := htmlContent.String()
	reader := strings.NewReader(htmlStr)
	doc, err := html.Parse(reader)
	if err != nil {
		panic(err)
		return
	}
	result := map[string][]string{}
	var find func(*html.Node, []string)
	find = func(n *html.Node, class []string) {
		if n.Type == html.ElementNode && n.Data == "span" {
			for c := n.FirstChild; c != nil; c = c.NextSibling {
				if c.Type == html.TextNode {
					c.Data = strings.TrimSpace(c.Data)
					if c.Data != "" {
						result[c.Data] = class
					}
				} else {
					cl := c.Attr[0].Val
					if cl != "line" && cl != "p" && cl != "cl" {
						class = append(class, cl)
					}
					find(c, class)
				}
			}
		} else {
			for c := n.FirstChild; c != nil; c = c.NextSibling {
				if len(c.Attr) > 0 {
					cl := c.Attr[0].Val
					if cl != "line" && cl != "p" && cl != "cl" {
						class = append(class, cl)
					}
				}
				find(c, class)
			}
		}
	}
	find(doc, []string{})

	var count = 1

	for k, v := range result {
		// response[k] = cssList[v[len(v)-1]]
		cssMap[strconv.Itoa(count)] = CssObj{
			Name:  k,
			Count: count,
			Color: cssList[v[len(v)-1]].Color,
		}
		count++
	}
	showWindow()
}

type CssObj struct {
	Name  string
	Count int
	Color color.NRGBA
}

func css(css string) {
	re := regexp.MustCompile(`(?s)\..*?\{.*?}`)
	matches := re.FindAllString(css, -1)

	for _, match := range matches {
		if strings.Contains(match, "color") {
			cs := parseCss(match)
			cssList[cs.Name] = cs
		}
	}
}

func parseCss(css string) CssObj {
	re := regexp.MustCompile(`.*\{`)
	matches := re.FindAllString(css, -1)
	name := strings.ReplaceAll(matches[0], "{", "")
	cName := strings.TrimSpace(name)
	if cName != ".chroma" {
		cName = strings.TrimSpace(strings.ReplaceAll(cName, ".chroma", ""))
	}
	cssObj := CssObj{
		Name: strings.ReplaceAll(cName, ".", ""),
	}
	re = regexp.MustCompile(`color:.*`)
	colors := re.FindAllString(css, -1)
	color := strings.ReplaceAll(colors[0], "color:", "")
	cssObj.Color = transColor(strings.TrimSpace(color))
	return cssObj
}

func transColor(hex string) color.NRGBA {
	hex = strings.ReplaceAll(hex, "}", "")
	if strings.TrimSpace(hex) == "inherit" {
		return color.NRGBA{
			R: 0,
			G: 0,
			B: 0,
			A: 255,
		}
	}
	c, err := colorful.Hex(hex)
	if err != nil {
		return color.NRGBA{}
	}
	return color.NRGBA{
		R: uint8(c.R * 255),
		G: uint8(c.G * 255),
		B: uint8(c.B * 255),
		A: 255,
	}
}

func showWindow() {

	var th = theme.NewTheme()
	card := widgets.NewCard(th)
	win := window.NewApplication(new(app.Window)).CenterWindow()
	win.Title("Hello, Gio!").Size(window.ElementSize{
		Height: 900,
		Width:  1200,
	})
	var TextState richtext.InteractiveText
	var cache []richtext.SpanStyle
	// for k, v := range response {
	// 	cache = append(cache, richtext.SpanStyle{
	// 		Content: k,
	// 		Size:    unit.Sp(20),
	// 		Color:   v.Color,
	// 	})
	// }

	for _, v := range cssMap {
		code = strings.ReplaceAll(code, v.Name, fmt.Sprint(v.Count)+"@")
	}
	temp1 := strings.Split(code, "\n")
	for _, items := range temp1 {
		temp2 := strings.Split(items, "@")
		for key1, v := range temp2 {
			if strings.TrimSpace(v) == "" {
				continue
			}
			v = strings.ReplaceAll(v, `"`, "")
			key := strings.TrimSpace(v)
			content := ""
			content = strings.ReplaceAll(v, key, "") + cssMap[key].Name
			content = strings.ReplaceAll(content, "\t", "    ")

			if key1 == len(temp2)-2 {
				content = content + "\n"
			}
			content = strings.ReplaceAll(content, "@", "")
			cache = append(cache, richtext.SpanStyle{
				Content: content,
				Size:    unit.Sp(15),
				Color:   cssMap[key].Color,
			})
		}
	}
	win.BackgroundColor(th.Color.DefaultWindowBgGrayColor)
	win.Frame(func(gtx layout.Context, ops op.Ops, win *app.Window) {
		layout.UniformInset(unit.Dp(20)).Layout(gtx, func(gtx layout.Context) layout.Dimensions {
			return layout.Flex{Axis: layout.Vertical}.Layout(gtx,
				layout.Rigid(func(gtx layout.Context) layout.Dimensions {
					return card.Layout(gtx, func(gtx layout.Context) layout.Dimensions {
						return layout.UniformInset(unit.Dp(4)).Layout(gtx, func(gtx layout.Context) layout.Dimensions {
							return richtext.Text(&TextState, th.Material().Shaper, cache...).Layout(gtx)
						})
					})
				}),
			)
		})
	})
	win.Run()
}
